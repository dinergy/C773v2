## C773v2 ##
Version 2 of WGU C773 Site

## Student Info ##
USER INTERFACE DESIGN - C773\
TNM1 — TASK 2: MULTIPAGE WEBSITE PROTOTYPE\
Shawn Parker\
Western Governors University\
Student ID: #001185841\
May 4, 2024

## Turn in notes ##
Please note, this project site utilizes two online frameworks to display content\
1. Fontawesome.com - CSS Fonts/Images/Icons
2. W3.CSS (https://www.w3schools.com/w3css/default.asp) - Display containers, styles, fonts, etc.

The site will not function correctly without internet access to retrieve the CSS framework calls.

The packages and code can be downloaded to be used offline locally if required but it's easier and more efficient to pull from their own online repositories.

Thanks!

-sp
